// خادم بنك الديني: يقدّم الصفحات ويحفظ بيانات البنك المشتركة لكل المستخدمين.
// بدون أي مكتبات. يحتاج Node 18 أو أحدث.
const http = require('http'), fs = require('fs'), path = require('path');
const PORT = process.env.PORT || 3000;
const FILE = process.env.DATA_FILE || path.join(__dirname, 'data', 'db.json');
const UP_URL = process.env.UPSTASH_REDIS_REST_URL, UP_TOKEN = process.env.UPSTASH_REDIS_REST_TOKEN;
const PUB = path.join(__dirname, 'public');
const TYPES = { '.html': 'text/html; charset=utf-8', '.js': 'text/javascript', '.png': 'image/png', '.webmanifest': 'application/manifest+json', '.json': 'application/json' };
let state = { v: 0, db: null };

async function up(cmd) {
  const r = await fetch(UP_URL, { method: 'POST', headers: { Authorization: 'Bearer ' + UP_TOKEN }, body: JSON.stringify(cmd) });
  if (!r.ok) throw new Error('Upstash ' + r.status);
  return (await r.json()).result;
}
async function load() {
  try {
    if (UP_URL) { const t = await up(['GET', 'aldeeni']); if (t) state = JSON.parse(t); }
    else if (fs.existsSync(FILE)) state = JSON.parse(fs.readFileSync(FILE, 'utf8'));
  } catch (e) { console.error('load failed', e.message); }
}
async function persist() {
  const t = JSON.stringify(state);
  if (UP_URL) return up(['SET', 'aldeeni', t]);
  fs.mkdirSync(path.dirname(FILE), { recursive: true });
  fs.writeFileSync(FILE + '.tmp', t); fs.renameSync(FILE + '.tmp', FILE);
}
const send = (res, code, obj) => { res.writeHead(code, { 'Content-Type': 'application/json', 'Cache-Control': 'no-store' }); res.end(JSON.stringify(obj)); };
let queue = Promise.resolve(); // يجعل الكتابات تتم واحدة بعد الأخرى

http.createServer((req, res) => {
  const u = new URL(req.url, 'http://x');
  if (u.pathname === '/api/db') {
    if (req.method === 'GET') {
      if (u.searchParams.get('v') !== null && Number(u.searchParams.get('v')) === state.v) { res.writeHead(204, { 'Cache-Control': 'no-store' }); return res.end(); }
      return send(res, 200, state);
    }
    if (req.method === 'POST') {
      let body = '', size = 0;
      req.on('data', c => { size += c.length; if (size > 20e6) req.destroy(); else body += c; });
      req.on('end', () => {
        queue = queue.then(async () => {
          let m; try { m = JSON.parse(body); } catch (e) { return send(res, 400, { error: 'bad json' }); }
          if (!m || typeof m.v !== 'number' || !m.db || typeof m.db !== 'object') return send(res, 400, { error: 'bad body' });
          if (m.v !== state.v) return send(res, 409, state);
          const prev = state; state = { v: state.v + 1, db: m.db };
          try { await persist(); send(res, 200, { v: state.v }); }
          catch (e) { state = prev; send(res, 500, { error: 'persist failed' }); }
        });
      });
      return;
    }
    return send(res, 405, { error: 'method' });
  }
  let p = path.normalize(decodeURIComponent(u.pathname)).replace(/^(\.\.[\/\\])+/, '');
  if (p === '/' || p === '\\') p = '/index.html';
  const f = path.join(PUB, p);
  if (!f.startsWith(PUB) || !fs.existsSync(f) || fs.statSync(f).isDirectory()) { res.writeHead(404); return res.end('Not found'); }
  res.writeHead(200, { 'Content-Type': TYPES[path.extname(f)] || 'application/octet-stream', 'Cache-Control': 'no-cache' });
  fs.createReadStream(f).pipe(res);
}).listen(PORT, async () => { await load(); console.log('بنك الديني يعمل على المنفذ ' + PORT + ' (النسخة ' + state.v + ')'); });
